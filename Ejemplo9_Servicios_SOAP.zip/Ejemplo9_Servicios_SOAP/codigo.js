// Función para consumir el servicio SOAP
function convertirTemperatura(celsius) {
    // Crear el objeto XMLHttpRequest
    var xhr = new XMLHttpRequest();
    
    // URL del servicio SOAP
    var url = 'https://www.w3schools.com/xml/tempconvert.asmx';
    
    // Abrir la conexión
    xhr.open('POST', url, true);
    
    // Establecer las cabeceras
    xhr.setRequestHeader('Content-Type', 'text/xml');
    xhr.setRequestHeader('SOAPAction', 'https://www.w3schools.com/xml/CelsiusToFahrenheit');
    
    // Preparar el mensaje SOAP
    var soapEnvelope = 
      '<?xml version="1.0" encoding="UTF-8"?>' +
      '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" ' +
                     'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' +
                     'xmlns:xsd="http://www.w3.org/2001/XMLSchema">' +
        '<soap:Body>' +
          '<CelsiusToFahrenheit xmlns="https://www.w3schools.com/xml/">' +
            '<Celsius>' + celsius + '</Celsius>' +
          '</CelsiusToFahrenheit>' +
        '</soap:Body>' +
      '</soap:Envelope>';
    
    // Manejar la respuesta
    xhr.onreadystatechange = function() {
      if (xhr.readyState == 4) {
        if (xhr.status == 200) {
          // Procesar la respuesta XML
          var xmlDoc = xhr.responseXML;
          //console.log(xmlDoc);
          var resultado = xmlDoc.getElementsByTagName('CelsiusToFahrenheitResult')[0].textContent;
          console.log('Resultado: ' + resultado + '°F');
          document.getElementById('resultado').innerHTML = celsius + '°C = ' + resultado + '°F';
        } else {
          console.error('Error en la solicitud SOAP: ' + xhr.status);
        }
      }
    };
    
    // Enviar la solicitud
    xhr.send(soapEnvelope);
  }
  
  // Evento para manejar el envío del formulario
  document.getElementById('formularioTemperatura').onsubmit = function(e) {
    e.preventDefault();
    var celsius = document.getElementById('celsius').value;
    convertirTemperatura(celsius);
  };