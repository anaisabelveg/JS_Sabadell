const nombre = "prueba.txt";
const contenido = "Este ejemplo es para probar a escribir ficheros de texto y simular una descarga";

function guardarDatos(nombre, contenido){

    // Crear el objeto BLOB con el contenido
    const blob = new Blob([contenido], {type: 'text/plain'});

    // Crear el enlace simulando la descarga
    let enlace = document.createElement('a');
    enlace.href = URL.createObjectURL(blob);
    enlace.download = nombre;

    // Agregar el enlace a la pagina
    document.body.appendChild(enlace);

    // Para que se pueda descargar hay que hacer click en el enlace
    enlace.click();
}

guardarDatos(nombre, contenido);