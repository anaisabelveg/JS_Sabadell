function leer(e){

    // Tomamos el nombre del fichero a leer
    let archivo = e.target.files[0];

    let reader = new FileReader();
    reader.onload = function(e) {
        let contenido = e.target.result;

        // Mostramos el contenido en el contenedor div
        document.getElementById('contenedor').textContent = contenido;
    }

    reader.readAsText(archivo);

}

// Cuando seleccionamos otro fichero leemos el contenido
document.getElementById('fichero').addEventListener('change', leer, false);