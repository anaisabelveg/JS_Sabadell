let i = 0;

function contador(){
    // recibir el mensaje
    onmessage = function(e){
        i = parseInt(e.data());
    };

    // Crear un temporizador de medio segundo que envie el valor de i incrementado al hilo principal
    setTimeout(() => {
        i++;
        postMessage(i);
        contador();
    }, 500);
}

contador();